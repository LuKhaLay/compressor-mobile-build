Compressor 1.6.5 - requested background/cache changes

Changes in this ZIP:
1. Added a foreground service with an ongoing notification and partial WakeLock while
   Media3 Transformer compression is active, so the process is less likely to be stopped
   when the app is backgrounded or the screen is off.
2. The foreground service is stopped on successful completion, terminal failure, cancel,
   or ViewModel cleanup.
3. Cancel removes the active incomplete output after Transformer cancellation has had
   time to stop writing. Terminal export failures also remove the incomplete output.
4. On next app launch, stale files under cacheDir/compressed_videos are removed recursively.

The existing H.264 hardware-to-software fallback logic and compression settings were
left unchanged. This is a source ZIP; build the APK locally.

Note: Android/OEM task killers can still terminate any app process. The foreground
service and WakeLock improve background execution reliability but cannot guarantee
survival against force-stop or aggressive vendor power management. Build and test on
the target device, including screen-off, app-background, cancel, and forced process death.
