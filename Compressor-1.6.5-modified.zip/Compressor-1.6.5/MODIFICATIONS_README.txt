Compressor 1.6.5 - requested modifications

1. Output filenames now preserve the original video's base name and no longer append "_Compressed".
   The exported container remains MP4, so the output extension is .mp4.
2. H.264 encoding starts with the normal preferred encoder path. If an H.264 encoder initialization/
   encoder-related failure is reported, the export is retried once using software-only H.264 encoders.
   H.265 behavior is not intentionally changed.

Build verification:
- Source edits were made in CompressorViewModel.kt.
- Gradle compilation could not be run in this environment because the Gradle distribution
  could not be downloaded (network/DNS unavailable). Please open in Android Studio and build
  to validate against your local Android SDK.
