Compressor 1.6.5 - background execution and temporary output cleanup patch

Changes in this ZIP:
1. The compression foreground service now explicitly supplies the mediaProcessing
   foreground-service type on Android 15/API 35+, and uses the legacy overload
   on earlier Android versions.
2. The service continues to hold a partial WakeLock while active and displays
   an ongoing notification.
3. Cancelled and terminal-failure output files are deleted with retry attempts
   to account for asynchronous Transformer/codec teardown.
4. Startup cache cleanup now removes only files in cacheDir/compressed_videos
   that are older than 24 hours. This avoids a startup cleanup race deleting a
   fresh output file created by a compression job.
5. Existing H.264 software fallback and compression settings are preserved.

Important limitations:
- The foreground service currently keeps the app process important; the actual
  Media3 Transformer is still managed by the ViewModel in the app process.
  This is not a fully process-independent service architecture. If Android/OEM
  kills the process, the active compression job can still be interrupted.
- Android's force-stop and aggressive OEM battery policies may still stop work.
- This patch was not compiled in this environment because the Gradle distribution
  download was unavailable (network/DNS failure) and an Android SDK was not
  detected. Please run a GitHub Actions build and test on-device before relying
  on it.

Suggested tests:
- Start compression and switch to another app.
- Turn the screen off for several minutes.
- Check notification/progress and completion.
- Cancel during compression and verify the temporary output is removed.
- Force an encoder/export failure and verify cleanup.
- Reopen the app after a day and verify stale cache cleanup.
